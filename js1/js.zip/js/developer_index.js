﻿  //JavaScript Document
tpl.index_apps = [
'<ul>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/801210285?via=801210285_WB.SEARCH.ALL.1.1"><img src="http://openmat.gtimg.com/pic/801210285_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/801210285?via=801210285_WB.SEARCH.ALL.1.1" title="八卦神器">八卦神器</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/170039?via=170039_WB.SEARCH.0.1.1"><img src="http://mat1.gtimg.com/app/opent/images/index/opent_index_gulu.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/170039?via=170039_WB.SEARCH.0.1.1" title="嘀咕">嘀咕</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/801126133?via=801126133_WB.SEARCH.ALL.1.1"><img src="http://openmat.gtimg.com/pic/801126133_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/801126133?via=801126133_WB.SEARCH.ALL.1.1" title="搜狐新闻客户端">搜狐新闻客户端</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/170065?via=170065_WB.SEARCH.0.1.1"><img src="http://ctc.i.gtimg.cn/qzonestyle/act/qzone_app_img/app170065_170065_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/170065?via=170065_WB.SEARCH.0.1.1" title="ZAKER">ZAKER</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/801130695?via=801130695_WB.SEARCH.ALL.1.1"><img src="http://openmat.gtimg.com/pic/801130695_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/801130695?via=801130695_WB.SEARCH.ALL.1.1" title="谁和我最配">谁和我最配</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/170045?via=170045_WB.SEARCH.0.1.1"><img src="http://ctc.i.gtimg.cn/qzonestyle/act/qzone_app_img/app170045_170045_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/170045?via=170045_WB.SEARCH.0.1.1" title="上辈子你是做啥的">上辈子你是做啥的</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/100628267?via=100628267_WB.SEARCH.ALL.1.1"><img src="http://openmat.gtimg.com/pic/100628267_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/100628267?via=100628267_WB.SEARCH.ALL.1.1" title="地下铁恋人">地下铁恋人</a></h3>',
	'</li>',
	'<li>',
		'<a target="_blank" href="http://app.t.qq.com/app/intro/170043?via=170043_WB.SEARCH.0.1.1"><img src="http://ctc.i.gtimg.cn/qzonestyle/act/qzone_app_img/app170043_170043_50.png"/></a>',
		'<h3><a target="_blank" href="http://app.t.qq.com/app/intro/170043?via=170043_WB.SEARCH.0.1.1" title="百度搜索框">百度搜索框</a></h3>',
	'</li>',
'</ul>'
].join("");
	
tpl.developer_index = 
[
	this.tpl.header, 
	'<link href="http://mat1.gtimg.com/app/opent/css/developer/index/development_index.css?20120525" rel="stylesheet" type="text/css" />',
	'<div class="banner">',
	'<div class="wrapper"> ',
	'<a href="http://wiki.open.t.qq.com/" style="top:167px;left:478px;"></a>',
	'<a href="javascript:;" style="top:167px;left:620px;" id="newapp"></a>',
	'<a href="javascript:;" style="top:167px;left:762px;" id="newgame"></a>',
	'</div>',
	'</div>',
'<div class="main wrapper">',
   '<div class="main_left">',
     '<h2 class="title">应用开发</h2>',
	 '<ul class="developer">',
	   '<li>',
		   '<a target="_blank" href="http://wiki.open.t.qq.com/index.php/API%E6%96%87%E6%A1%A3" class="icon"><img src="http://mat1.gtimg.com/app/opent/images/developer/index/development_index_02.gif" /></a>',
		   '<h4><a target="_blank" href= "http://wiki.open.t.qq.com/index.php/API%E6%96%87%E6%A1%A3">API文档</a></h4>',
		   '<p><a target="_blank" href="http://wiki.open.t.qq.com/index.php/API%E6%96%87%E6%A1%A3">API接口描述及说明文档，包括基础数据API、搜索API和位置信息API</a></p>',
	   '</li>',
	   '<li>',
		   '<a target="_blank"  href="http://wiki.open.t.qq.com/index.php/SDK%E4%B8%8B%E8%BD%BD" class="icon"><img src="http://mat1.gtimg.com/app/opent/images/developer/index/development_index_03.gif" /></a>',
		   '<h4><a target="_blank"  href="http://wiki.open.t.qq.com/index.php/SDK%E4%B8%8B%E8%BD%BD">SDK下载</a></h4>',
		   '<p><a target="_blank"  href="http://wiki.open.t.qq.com/index.php/SDK%E4%B8%8B%E8%BD%BD">开发工具包，包括Adobe Air、PHP/Python、Java等流行语言</a> ',
		   '</p>',
		   '<div class="tooltip" id="tooltip" style="display:block;margin-left:80px;margin-top:5px;"><div class="toolangle"><span class="a1">◆</span><span class="a2">◆</span></div><div class="tooltext"><a href="http://wiki.open.t.qq.com/index.php/%E7%A7%BB%E5%8A%A8%E5%BA%94%E7%94%A8%E6%8E%A5%E5%85%A5" target="_blank" title="新增移动应用SDK" style="color:#333;">新增移动应用SDK</a></div></div>',
	   '</li>',
	   '<li>',
	   		'<a target="_blank" href="http://wiki.open.t.qq.com/index.php/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98%E8%A7%A3%E7%AD%94" class="icon"><img src="http://mat1.gtimg.com/app/opent/images/developer/index/development_index_04.gif" /></a>',
			'<h4><a target="_blank" href="http://wiki.open.t.qq.com/index.php/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98%E8%A7%A3%E7%AD%94">常见问题</a></h4>',
			'<p><a target="_blank" href="http://wiki.open.t.qq.com/index.php/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98%E8%A7%A3%E7%AD%94">开发，审核，接口权限、应用调优等常见问题</a></p>',
		'</li>',
		'<li>',
	    	'<a target="_about" href ="http://bbs.open.t.qq.com/" class="icon"><img src="http://mat1.gtimg.com/app/opent/images/developer/index/development_index_05.gif" /></a>',
			'<h4><a target="_about" href ="http://bbs.open.t.qq.com/">交流论坛</a></h4>',
			'<p><a target="_about" href ="http://bbs.open.t.qq.com/">开发者技术交流园地，提供运营商务支持。</a></p>',
		'</li>',
	 '</ul>',
   '</div>',
   '<div class="main_right demos">',
	 '<h2 class="title">优秀应用介绍</h2>',
	 tpl.index_apps,
  '</div>',
'</div>',
 	this.tpl.footer
].join("");

$('#main').html(tmpl(tpl.developer_index, global_obj.data));

util.setLoginInfo();
window.init();
var userInfo = global_obj.data.userInfo;
var developer  = global_obj.data.developer_detail;

var hdlogin = userInfo.hdlogin || '';
var regweibo = userInfo.reg_wb;
var insiteAppAble=1;

$("#newapp").click(function(){
	if( hdlogin==undefined || hdlogin == false || hdlogin == 'false' ){
			return checkuserLogin(encodeURIComponent(location.href.replace(location.search,"").replace(location.hash,"")+"?t="+(~new Date())+"#newapp"));
	}else{
		if( userInfo.reg_wb == 0 ){
			location.href = "http://reg.t.qq.com/invite.php";
			return;
		}
		popAppWin(global_obj.data.developer.user_app_numbers,global_obj.data.developer.user_app_limit); 
	}
});
$("#newgame").click(function(){
	if( hdlogin==undefined || hdlogin == false || hdlogin == 'false'){
		return checkuserLogin(encodeURIComponent("http://" + location.host+"/apps/add/4?cid=3"));		
	}else{
		if( userInfo.reg_wb == 0 ){
			location.href = "http://reg.t.qq.com/invite.php";
			return;
		}
		popAppWin(global_obj.data.developer.user_app_numbers,global_obj.data.developer.user_app_limit); 
	}
	return false;
});
	
if( hdlogin==undefined || hdlogin == false || hdlogin == 'false'){
	$(".demos").find("a").removeAttr("target").click(function(){
		return (!!checkuserLogin(encodeURIComponent($(this).attr("href"))));
	})
}else{
	if (location.hash=="#newapp"){
		$("#newapp").trigger("click");
	}else if(location.hash=="#newgame"){
		$("#newgame").trigger("click");
	}
}	

QosSS.c = new Image();
QosSS.c.onload = (QosSS.c.onerror = function() {delete QosSS.c;});
QosSS.t[5]= (new Date()).getTime();
QosSS.c.src="http://qos.report.qq.com/collect?type=1&name="+"opent_dev_index"+"&1="+ (QosSS.t[1]- QosSS.t[0])+"&2="+ (QosSS.t[2]- QosSS.t[0])+ "&3="+ (QosSS.t[3]- QosSS.t[0])+"&4="+ (QosSS.t[4]- QosSS.t[0])+ "&5="+ (QosSS.t[5]- QosSS.t[0]);




 