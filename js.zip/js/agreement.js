//JavaScript Document
this.tpl = this.tpl||{};
this.tpl.agreement = [
	'<li>',
		'<label class="form_label">&nbsp;</label>',
		'<div class="form_element"  style="line-height:20px;">',
		'<input type="checkbox" name="user_agree" id="user_agree">' ,
		'<label for="user_agree">我同意接受</label>',
		'<a target="_blank" href="/index/agreement/" class="valign">《腾讯微博开放平台开发者服务协议》</a>',
		'<br/>',
		'<input type="checkbox" name="user_agree" id="user_agree2" agreement="腾讯微博开放平台第三方应用审核规范">', 
		'<label for="user_agree2">我同意接受</label>',
		'<a target="_blank" href="http://wiki.open.t.qq.com/index.php/%E8%85%BE%E8%AE%AF%E5%BE%AE%E5%8D%9A%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0%E7%AC%AC%E4%B8%89%E6%96%B9%E5%BA%94%E7%94%A8%E5%AE%A1%E6%A0%B8%E8%A7%84%E8%8C%83" class="valign">《腾讯微博开放平台第三方应用审核规范》</a>',
		'</div>',
	'</li>'
].join("");
